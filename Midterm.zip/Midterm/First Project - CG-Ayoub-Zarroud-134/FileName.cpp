#include <stdlib.h>
#include <GL/glut.h>
#include <math.h>

#define PI 3.14159265358979323846f

GLfloat rotationAngle = 0.0f;
GLfloat scaleX = 1.0f;
GLfloat scaleY = 1.0f;
GLfloat objectX = 0.0f;
GLfloat objectY = 0.0f;
GLfloat aspect = 1.0f;

int drawPerimeter = 0;
int moveHorizontal = 0;
float snowflakes[100][2];
int isSnowfallEnabled = 0;
int snowfallSpeed = 10;

void drawSnowflakes() {
    glColor3f(1.0, 1.0, 1.0);
    glPointSize(2.0);
    glBegin(GL_POINTS);
    for (int i = 0; i < 100; i++) {
        glVertex2f(snowflakes[i][0], snowflakes[i][1]);
    }
    glEnd();
}

void updateSnowflakes() {
    for (int i = 0; i < 100; i++) {
        snowflakes[i][1] -= 0.01;
        if (snowflakes[i][1] < -1.0) {
            snowflakes[i][0] = (float)(rand() % 2000 - 1000) / 1000.0;
            snowflakes[i][1] = 1.0;
        }
    }
}

void init(void) {
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    for (int i = 0; i < 100; i++) {
        snowflakes[i][0] = (float)(rand() % 2000 - 1000) / 1000.0;
        snowflakes[i][1] = (float)(rand() % 2000 - 1000) / 1000.0;
    }
}

void display(void) {
    glClear(GL_COLOR_BUFFER_BIT);
    if (isSnowfallEnabled) {
        drawSnowflakes();
        updateSnowflakes();
    }

    glPushMatrix();

    glTranslatef(objectX, objectY, 0.0f);
    glRotatef(rotationAngle, 0.0f, 0.0f, 1.0f);
    glScalef(scaleX, scaleY, 1.0f);

    glColor3f(1.0f, 0.0f, 0.0f);
    if (drawPerimeter) {
        glBegin(GL_LINE_LOOP);
    }
    else {
        glBegin(GL_QUADS);
    }
    glVertex2f(-0.9f, 0.9f);
    glVertex2f(-0.7f, 0.9f);
    glVertex2f(-0.7f, 0.6f);
    glVertex2f(-0.9f, 0.6f);
    glEnd();

    glColor3f(0.0f, 0.0f, 1.0f);
    if (drawPerimeter) {
        glBegin(GL_LINE_LOOP);
    }
    else {
        glBegin(GL_TRIANGLES);
    }
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex2f(0.7f, 0.9f);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex2f(0.9f, 0.9f);
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(0.8f, 0.7f);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f);
    if (drawPerimeter) {
        glBegin(GL_LINE_LOOP);
    }
    else {
        glBegin(GL_LINES);
    }
    glVertex2f(-0.9f, -0.9f);
    glVertex2f(-0.7f, -0.9f);
    glEnd();

    glColor3f(1.0f, 1.0f, 0.0f);
    if (drawPerimeter) {
        glBegin(GL_LINE_LOOP);
    }
    else {
        glBegin(GL_TRIANGLE_FAN);
    }
    glVertex2f(0.8f, -0.8f);
    int numSegments = 100;
    for (int i = 0; i <= numSegments; i++) {
        float angle = 2.0f * PI * i / numSegments;
        float x = 0.1f * cos(angle);
        float y = 0.1f * sin(angle);
        glVertex2f(x + 0.8f, y - 0.8f);
    }
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f);
    if (drawPerimeter) {
        glBegin(GL_LINE_LOOP);
    }
    else {
        glBegin(GL_POLYGON);
    }
    for (int i = 0; i < 5; i++) {
        float angle = 2.0f * PI * i / 5;
        float x = 0.1f * cos(angle);
        float y = 0.1f * sin(angle);
        glVertex2f(x, y);
    }
    glEnd();

    glColor3f(1.0f, 0.5f, 0.5f);
    if (drawPerimeter) {
        glBegin(GL_LINE_LOOP);
    }
    else {
        glBegin(GL_QUADS);
    }
    glVertex2f(-0.05f, -0.05f);
    glVertex2f(0.05f, -0.05f);
    glVertex2f(0.05f, 0.05f);
    glVertex2f(-0.05f, 0.05f);
    glEnd();

    glPopMatrix();

    glFlush();
}

void reshape(GLsizei width, GLsizei height) {
    if (height == 0) height = 1;
    aspect = (GLfloat)width / (GLfloat)height;
    glViewport(0, 0, width, height);
}

void keyboard(unsigned char key, int x, int y) {
    if (key == 'n') {
        isSnowfallEnabled = 1;
    }
    else if (key == 's') {
        isSnowfallEnabled = 0;
    }
    else {
        switch (key) {
        case 27:
            exit(0);
            break;
        case 'r':
            rotationAngle += 10.0;
            break;
        case 'h':
            objectX += 0.1;
            break;
        case 'f':
            objectX -= 0.1;
            break;
        case 't':
            objectY += 0.1;
            break;
        case 'g':
            objectY -= 0.1;
            break;
        case 'z':
            scaleX += 0.1;
            scaleY += 0.1;
            break;
        case 'd':
            scaleX -= 0.1;
            scaleY -= 0.1;
            break;
        case 'c':
            rotationAngle = 0.0f;
            scaleX = 1.0f;
            scaleY = 1.0f;
            objectX = 0.0f;
            objectY = 0.0f;
            break;
        case 'p':
            drawPerimeter = !drawPerimeter;
            break;
        case '+':
            snowfallSpeed -= 10;
            break;
        case '-':
            snowfallSpeed += 10;
            if (snowfallSpeed < 10) {
                snowfallSpeed = 10;
            }
            break;
        }
    }
    glutPostRedisplay();
}

void animation(int value) {
    glutPostRedisplay();

    // Add the rotating object animation
    rotationAngle += 1.0;
    if (rotationAngle >= 360.0) {
        rotationAngle -= 360.0;
    }

    // Add the scaling object animation
    static int grow = 1;
    if (grow) {
        scaleX += 0.01;
        scaleY += 0.01;
    }
    else {
        scaleX -= 0.01;
        scaleY -= 0.01;
    }
    if (scaleX >= 1.5 || scaleX <= 0.5) {
        grow = !grow;
    }

    // Add the translating object animation
    static int moveRight = 1;
    if (moveRight) {
        objectX += 0.01;
    }
    else {
        objectX -= 0.01;
    }
    if (objectX >= 0.4 || objectX <= -0.4) {
        moveRight = !moveRight;
    }

    // Adjust snowfall speed using '+' and '-' keys

    if (isSnowfallEnabled) {
        glutTimerFunc(snowfallSpeed, animation, 0);
    }
    else {
        glutTimerFunc(100, animation, 0);
    }
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitWindowSize(512, 512);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("2D scene");

    init();

    glutTimerFunc(100, animation, 0);
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}

//This code includes the animations for rotating, scaling, translating the object, and adjusting the snowfall speed using the '+' and '-' keys.
/*
#include <stdlib.h>
#include <GL/glut.h>
#include <math.h>

#define PI 3.14159265358979323846f

GLfloat rotationAngle = 0.0f;
GLfloat scaleX = 1.0f;
GLfloat scaleY = 1.0f;
GLfloat objectX = 0.0f;
GLfloat objectY = 0.0f;
GLfloat aspect = 1.0f;

int drawPerimeter = 0;
int moveHorizontal = 0;
float snowflakes[100][2];
int isSnowfallEnabled = 0;
int snowfallSpeed = 10;

void drawSnowflakes() {
    glColor3f(1.0, 1.0, 1.0);
    glPointSize(2.0);
    glBegin(GL_POINTS);
    for (int i = 0; i < 100; i++) {
        glVertex2f(snowflakes[i][0], snowflakes[i][1]);
    }
    glEnd();
}

void updateSnowflakes() {
    for (int i = 0; i < 100; i++) {
        snowflakes[i][1] -= 0.01;
        if (snowflakes[i][1] < -1.0) {
            snowflakes[i][0] = (float)(rand() % 2000 - 1000) / 1000.0;
            snowflakes[i][1] = 1.0;
        }
    }
}

void init(void) {
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    for (int i = 0; i < 100; i++) {
        snowflakes[i][0] = (float)(rand() % 2000 - 1000) / 1000.0;
        snowflakes[i][1] = (float)(rand() % 2000 - 1000) / 1000.0;
    }
}

void display(void) {
    glClear(GL_COLOR_BUFFER_BIT);
    if (isSnowfallEnabled) {
        drawSnowflakes();
        updateSnowflakes();
    }

    glPushMatrix();

    glTranslatef(objectX, objectY, 0.0f);
    glRotatef(rotationAngle, 0.0f, 0.0f, 1.0f);
    glScalef(scaleX, scaleY, 1.0f);

    glColor3f(1.0f, 0.0f, 0.0f);
    if (drawPerimeter) {
        glBegin(GL_LINE_LOOP);
    }
    else {
        glBegin(GL_QUADS);
    }
    glVertex2f(-0.9f, 0.9f);
    glVertex2f(-0.7f, 0.9f);
    glVertex2f(-0.7f, 0.6f);
    glVertex2f(-0.9f, 0.6f);
    glEnd();

    glColor3f(0.0f, 0.0f, 1.0f);
    if (drawPerimeter) {
        glBegin(GL_LINE_LOOP);
    }
    else {
        glBegin(GL_TRIANGLES);
    }
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex2f(0.7f, 0.9f);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex2f(0.9f, 0.9f);
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex2f(0.8f, 0.7f);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f);
    if (drawPerimeter) {
        glBegin(GL_LINE_LOOP);
    }
    else {
        glBegin(GL_LINES);
    }
    glVertex2f(-0.9f, -0.9f);
    glVertex2f(-0.7f, -0.9f);
    glEnd();

    glColor3f(1.0f, 1.0f, 0.0f);
    if (drawPerimeter) {
        glBegin(GL_LINE_LOOP);
    }
    else {
        glBegin(GL_TRIANGLE_FAN);
    }
    glVertex2f(0.8f, -0.8f);
    int numSegments = 100;
    for (int i = 0; i <= numSegments; i++) {
        float angle = 2.0f * PI * i / numSegments;
        float x = 0.1f * cos(angle);
        float y = 0.1f * sin(angle);
        glVertex2f(x + 0.8f, y - 0.8f);
    }
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f);
    if (drawPerimeter) {
        glBegin(GL_LINE_LOOP);
    }
    else {
        glBegin(GL_POLYGON);
    }
    for (int i = 0; i < 5; i++) {
        float angle = 2.0f * PI * i / 5;
        float x = 0.1f * cos(angle);
        float y = 0.1f * sin(angle);
        glVertex2f(x, y);
    }
    glEnd();

    glColor3f(1.0f, 0.5f, 0.5f);
    if (drawPerimeter) {
        glBegin(GL_LINE_LOOP);
    }
    else {
        glBegin(GL_QUADS);
    }
    glVertex2f(-0.05f, -0.05f);
    glVertex2f(0.05f, -0.05f);
    glVertex2f(0.05f, 0.05f);
    glVertex2f(-0.05f, 0.05f);
    glEnd();

    glPopMatrix();

    glFlush();
}

void reshape(GLsizei width, GLsizei height) {
    if (height == 0) height = 1;
    aspect = (GLfloat)width / (GLfloat)height;
    glViewport(0, 0, width, height);
}

void keyboard(unsigned char key, int x, int y) {
    if (key == 'n') {
        isSnowfallEnabled = 1;
    }
    else if (key == 's') {
        isSnowfallEnabled = 0;
    }
    else {
        switch (key) {
            case 27:
                exit(0);
                break;
            case 'r':
                rotationAngle += 10.0;
                break;
            case 'h':
                objectX += 0.1;
                break;
            case 'f':
                objectX -= 0.1;
                break;
            case 't':
                objectY += 0.1;
                break;
            case 'g':
                objectY -= 0.1;
                break;
            case 'z':
                scaleX += 0.1;
                scaleY += 0.1;
                break;
            case 'd':
                scaleX -= 0.1;
                scaleY -= 0.1;
                break;
            case 'c':
                rotationAngle = 0.0f;
                scaleX = 1.0f;
                scaleY = 1.0f;
                objectX = 0.0f;
                objectY = 0.0f;
                break;
            case 'p':
                drawPerimeter = !drawPerimeter;
                break;
            case '+':
                snowfallSpeed -= 10;
                break;
            case '-':
                snowfallSpeed += 10;
                if (snowfallSpeed < 10) {
                    snowfallSpeed = 10;
                }
                break;
        }
    }
    glutPostRedisplay();
}

void animation(int value) {
    glutPostRedisplay();

    // Add the rotating object animation
    rotationAngle += 1.0;
    if (rotationAngle >= 360.0) {
        rotationAngle -= 360.0;
    }

    // Add the scaling object animation
    static int grow = 1;
    if (grow) {
        scaleX += 0.01;
        scaleY += 0.01;
    } else {
        scaleX -= 0.01;
        scaleY -= 0.01;
    }
    if (scaleX >= 1.5 || scaleX <= 0.5) {
        grow = !grow;
    }

    // Add the translating object animation
    static int moveRight = 1;
    if (moveRight) {
        objectX += 0.01;
    } else {
        objectX -= 0.01;
    }
    if (objectX >= 0.4 || objectX <= -0.4) {
        moveRight = !moveRight;
    }

    // Adjust snowfall speed using '+' and '-' keys

    if (isSnowfallEnabled) {
        glutTimerFunc(snowfallSpeed, animation, 0);
    } else {
        glutTimerFunc(100, animation, 0);
    }
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitWindowSize(512, 512);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("2D scene");

    init();

    glutTimerFunc(100, animation, 0);
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}
*/