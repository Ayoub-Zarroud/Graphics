Introduction to Computer Graphics
Autumn term 2023 Project 2

Student Name: 
Student ID: 

This Demo shows a puppet.

In the menu, you can choose...
1/. "Run!", my puppet does not know how to walk, he can only RUN;
2/. "Stop Running.", my puppet is not willing to stop once he is running, but he follows this only command;
3/. "How do I ..", my puppet follows some more commands mentioned belowed, the keyboard events can be found in this option;
4/. "Bye~", see you next time!

   The keyboard events correspondence are: 

	"q","Q": rotate left upper arm backward, forward about the shoulder
	"w","W": rotate right upper arm backward, forward about the shoulder
	"e","E": rotate left forearm downward, upward about the elbow
	"r","R": rotate right forearm downward, upward about the elbow
	"y","Y": rotate torso left about the waist
	"u","U": rotate torso forward and backward about the waist
	"a","A": rotate left upper leg backward, forward about the hip
	"s","S": rotate right upper leg backward, forward about the hip
	"d","D": rotate left lower leg downward, upward about the knee
	"f","F": rotate right lower leg downward, upward about the knee
	"g","G": rotate left foot backward, forward about the ankle
	"h","H": rotate right foot backward, forward about the ankle
	
	Key_UP:     rotate the camera upward        
	Key_DOWN:   rotate the camera downward
	Key_LEFT:   rotate the camera left         
	Key_RIGHT:  rotate the camera right 

	"k","l": rotate light around X axis
	"o","p": rotate light around Y axis
